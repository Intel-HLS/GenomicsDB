#! /usr/bin/python3

"""
  The MIT License (MIT)
  Copyright (c) 2016-2017 Intel Corporation

  Permission is hereby granted, free of charge, to any person obtaining a copy of
  this software and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the rights to
  use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
  the Software, and to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
  FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
  COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
  IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

from collections import namedtuple

#### config json templates
# 'to_tiledb' is based on 1000g
# "size_per_column_partition": num_vcfs * COL_PARTITION_SIZE_UNIT, for 1000g is 1000
COL_PARTITION_SIZE_UNIT = 16384                     # used in load_cfg:size_per_column_partition
# "vcf_header_filename" not needed for good vcf /home/mingrutar/GenomicsDBPerfTest/templates/template_vcf_header.vcf",
__GENODB_ATTRIBUTES = ["REF", "ALT", "BaseQRankSum", "MQ", "MQ0", "ClippingRankSum", "MQRankSum", "ReadPosRankSum", "DP", \
"GT", "GQ", "SB", "AD", "PL", "DP_FORMAT", "MIN_DP"]

__cfg_json_t = {
    "combine_vcf" : {
        "produce_combined_vcf": True,
        "num_parallel_vcf_files": 1,
        "callset_mapping_file" : "",
        "vcf_output_format" : "z",
        "vcf_output_filename" : "",
        "index_output_VCF": True,
        "reference_genome" : "",
        "column_partitions" : [],
        "do_ping_pong_buffering" : True,
        "offload_vcf_output_processing" : True,
        "produce_GT_field" : True,
        "size_per_column_partition" : COL_PARTITION_SIZE_UNIT,
        "vid_mapping_file": ""},
    "to_tiledb" :  {
        "callset_mapping_file": "",
        "column_partitions": [],
        "compress_tiledb_array": True,
        "delete_and_create_tiledb_array": True,
        "disable_synced_writes": True,
        "discard_vcf_index": True,
        "do_ping_pong_buffering": False,
        "ignore_cells_not_in_partition": False,
        "num_cells_per_tile": 1000,
        "index_output_VCF": True,
        "num_parallel_vcf_files": 1,
        "offload_vcf_output_processing": True,
        "produce_combined_vcf": False,
        "produce_tiledb_array": True,
        "reference_genome": "/data/broad/samples/joint_variant_calling/broad_reference/Homo_sapiens_assembly19.fasta",
        "row_based_partitioning": False,
        "segment_size": 10485760,
        "size_per_column_partition": 1000 * COL_PARTITION_SIZE_UNIT,       # assume 1000 Genomics
        "tiledb_compression_level": 6,
        "treat_deletions_as_intervals": True,
        "lb_callset_row_idx": 0,
        "ub_callset_row_idx": 999,
        "vcf_header_filename": "",
        "vcf_output_format": "z",
        "vid_mapping_file": "/home/mingrutar/GenomicsDBPerfTest/templates/vid.json"},
    "query_full_scan" : {
        "array": ["TEST0"],
        "callset_mapping_file": "temp",
        "query_attributes": __GENODB_ATTRIBUTES,
        "reference_genome": "/data/broad/samples/joint_variant_calling/broad_reference/Homo_sapiens_assembly19.fasta",
        "scan_full": True,
        "segment_size": 10000,
        "vid_mapping_file": "/home/mingrutar/GenomicsDBPerfTest/templates/vid.json",
        "workspace": "/mnt/app_hdd1/scratch/gen10k/tiledb-ws_bn16-2/"},
    "query_density" : {
        "array": ["TEST0"],
        "callset_mapping_file": "temp",
        "query_attributes": __GENODB_ATTRIBUTES,
        "reference_genome": "/data/broad/samples/joint_variant_calling/broad_reference/Homo_sapiens_assembly19.fasta",
        "query_column_ranges" : [[3095999, 9287998, 15479997]],
        "segment_size": 10000,
        "vid_mapping_file": "/home/mingrutar/GenomicsDBPerfTest/templates/vid.json",
        "workspace": "/mnt/app_hdd1/scratch/gen10k/tiledb-ws_bn16-2/"},
    "histogram" : {
        "column_partitions" : [{"begin": 0}],
        "callset_mapping_file" : "",
        "vid_mapping_file" : "",
        "num_converter_processes" : 1,
        "max_histogram_range" : 3999999999,
        "num_bins" : 100000,
        "size_per_column_partition": 16384,
        "num_parallel_vcf_files" : 1}
}
def __get_nt(name, cfg):
    nt_tags = namedtuple(name, ','.join(cfg.keys()))
    return nt_tags(**cfg)

def __query_nt(name, qcfg, num_parallel):
    qcfg["array"] = ["TEST%d" % i for i in range(num_parallel)]
    return __get_nt(name, qcfg)

LOADER_CFG_T = lambda: __get_nt('nt_tdb_loader', __cfg_json_t['to_tiledb'])
# partition is empty
LOADER_COMBINER_CFG_T = lambda: __get_nt('nt_combine_vcf', __cfg_json_t['combine_vcf'])
# query_column_ranges is empty
QUERY_CFG_T = lambda num_par: __query_nt("nt_query", __cfg_json_t["query_density"], num_par)
QUERY_FULL_SCAN_CFG_T = lambda num_par: __query_nt("nt_query_full", __cfg_json_t["query_full_scan"], num_par)

CREATE_COL_PARTITION_F = lambda array_start_pos, tdb_ws: [{"array": "TEST%d" % (i), "begin": begin, "workspace": tdb_ws} \
            for i, begin in enumerate(array_start_pos)]

HISTOGRAM_CFG_T = lambda: __get_nt('nt_histogram', __cfg_json_t['histogram'])
